let filmsContainer=document.createElement('ul');
filmsContainer.setAttribute('class', 'films_container');
for(let film of films) {
   let filmAbout=document.createElement('li');
   let filmTitle=document.createElement('p');
   let filmImage=document.createElement('img');
   let filmOverview=document.createElement('p');
   let filmTime=document.createElement('time');
   let filmGenres=document.createElement('ul');

   filmAbout.setAttribute('class', 'film_about');
   filmTitle.textContent=film.title;
   filmImage.setAttribute('src', film.img);
   filmOverview.textContent=film.overview;
   filmTime.textContent=normalizeDate(film.during_time);

   for(let genre of film.genres) {
      let filmGenre=document.createElement('li');
      filmGenre.textContent=genre;
      filmGenres.appendChild(filmGenre);
   }

   filmAbout.appendChild(filmTitle);
   filmAbout.appendChild(filmImage);
   filmAbout.appendChild(filmOverview);
   filmAbout.appendChild(filmTime);
   filmAbout.appendChild(filmGenres);
   filmsContainer.appendChild(filmAbout);
}
document.body.appendChild(filmsContainer);
